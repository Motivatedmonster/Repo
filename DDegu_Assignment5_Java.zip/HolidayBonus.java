package assginment5;

public class HolidayBonus {

	   public static final double BONUS_OTHER = 2000.0;
	   public static final double BONUS_HIGHEST = 5000.0;
	   public static final double BONUS_LOWEST = 1000.0;

	   public static double[] calculateHolidayBonus(double[][] salesData) {
	       double[] bonusArray = new double[salesData.length];
	       int totalColumns = 0;

	       for (double[] salesRow : salesData) {
	           if (salesRow.length > totalColumns) totalColumns = salesRow.length;
	       }

	       for (int currentColumn = 0; currentColumn < totalColumns; currentColumn++) {
	           int indexHighest = TwoDimRaggedArrayUtility.getHighestInColumnIndex(salesData, currentColumn);
	           int indexLowest = TwoDimRaggedArrayUtility.getLowestInColumnIndex(salesData, currentColumn);

	           for (int currentRow = 0; currentRow < salesData.length; currentRow++) {
	               if (currentColumn >= salesData[currentRow].length || salesData[currentRow][currentColumn] <= 0) continue;

	               if (currentRow == indexHighest) {
	                   bonusArray[currentRow] += BONUS_HIGHEST;
	               } else if (currentRow == indexLowest) {
	                   bonusArray[currentRow] += BONUS_LOWEST;
	               } else {
	                   bonusArray[currentRow] += BONUS_OTHER;
	               }
	           }
	       }
	       return bonusArray;
	   }

	   public static double calculateTotalHolidayBonus(double[][] salesData) {
	       double[] bonusArray = calculateHolidayBonus(salesData);
	       double totalBonus = 0;
	       for (double individualBonus : bonusArray) {
	           totalBonus += individualBonus;
	       }
	       return totalBonus;
	   }
	}



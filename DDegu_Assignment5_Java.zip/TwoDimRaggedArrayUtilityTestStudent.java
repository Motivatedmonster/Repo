package assginment5;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TwoDimRaggedArrayUtilityTestStudent {

    private double[][] testData;

    @Before
    public void setUp() throws Exception {
        testData = new double[][] {
            {2, 5, 3},
            {6, 7},
            {7, 8, 9, 0}
        };
    }

    @After
    public void tearDown() throws Exception {
        testData = null;
    }

    @Test
    public void testGetRowTotal() {
        assertEquals(10.0, TwoDimRaggedArrayUtility.getRowTotal(testData, 0), 0.001);
        assertEquals(13.0, TwoDimRaggedArrayUtility.getRowTotal(testData, 1), 0.001);
        assertEquals(24.0, TwoDimRaggedArrayUtility.getRowTotal(testData, 2), 0.001);
    }

    @Test
    public void testGetColumnTotal() {
        assertEquals(15.0, TwoDimRaggedArrayUtility.getColumnTotal(testData, 0), 0.001);
        assertEquals(20.0, TwoDimRaggedArrayUtility.getColumnTotal(testData, 1), 0.001);
        assertEquals(12.0, TwoDimRaggedArrayUtility.getColumnTotal(testData, 2), 0.001);
        assertEquals(0.0, TwoDimRaggedArrayUtility.getColumnTotal(testData, 3), 0.001);
    }

    @Test
    public void testGetTotal() {
        assertEquals(47.0, TwoDimRaggedArrayUtility.getTotal(testData), 0.001);
    }

    @Test
    public void testGetAverage() {
        assertEquals(5.222, TwoDimRaggedArrayUtility.getAverage(testData), 0.001);
    }

    @Test
    public void testGetHighestInRow() {
        assertEquals(5.0, TwoDimRaggedArrayUtility.getHighestInRow(testData, 0), 0.001);
        assertEquals(7.0, TwoDimRaggedArrayUtility.getHighestInRow(testData, 1), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInRow(testData, 2), 0.001);
    }

    @Test
    public void testGetLowestInRow() {
        assertEquals(2.0, TwoDimRaggedArrayUtility.getLowestInRow(testData, 0), 0.001);
        assertEquals(6.0, TwoDimRaggedArrayUtility.getLowestInRow(testData, 1), 0.001);
        assertEquals(0.0, TwoDimRaggedArrayUtility.getLowestInRow(testData, 2), 0.001);
    }

    @Test
    public void testGetHighestInArray() {
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInArray(testData), 0.001);
    }

    @Test
    public void testGetLowestInArray() {
        assertEquals(0.0, TwoDimRaggedArrayUtility.getLowestInArray(testData), 0.001);
    }
}

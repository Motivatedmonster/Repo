package assginment5;

import static org.junit.Assert.*;
import org.junit.Test;

public class HolidayBonusTestStudent {

    @Test
    public void testCalculateBonuses() {
        double[][] salesData = {
            {1.0, 2.0, 3.0},
            {4.0, 0.0, 6.0},
            {7.0, 8.0, -1.0}
        };

        double[] expectedResults = {
            3000.0, 
            8000.0, 
            9000.0  
        };

        double[] calculatedResults = HolidayBonus.calculateHolidayBonus(salesData);

        assertArrayEquals(expectedResults, calculatedResults, 0.001);
    }

    @Test
    public void testCalculateTotalBonuses() {
        double[][] salesData = {
            {1.0, 2.0, 3.0},
            {4.0, 0.0, 6.0},
            {7.0, 8.0, -1.0}
        };

        double expectedTotal = 20000.0; 
        double calculatedTotal = HolidayBonus.calculateTotalHolidayBonus(salesData);

        assertEquals(expectedTotal, calculatedTotal, 0.001);
    }

    @Test
    public void testEdgeCaseBonuses() {
        
        double[][] emptySalesData = {};
        double[] expectedEmptyResults = {};
        double calculatedEmptyTotal = HolidayBonus.calculateTotalHolidayBonus(emptySalesData);
        assertArrayEquals(expectedEmptyResults, HolidayBonus.calculateHolidayBonus(emptySalesData), 0.001);
        assertEquals(0.0, calculatedEmptyTotal, 0.001);

        
        double[][] singleRowSalesData = {
            {5.0, 10.0, 15.0}
        };
        double[] expectedSingleRowResults = {15000.0}; 
        assertArrayEquals(expectedSingleRowResults, HolidayBonus.calculateHolidayBonus(singleRowSalesData), 0.001);
        assertEquals(15000.0, HolidayBonus.calculateTotalHolidayBonus(singleRowSalesData), 0.001);

        
        double[][] singleColumnSalesData = {
            {5.0},
            {10.0},
            {15.0}
        };
        double[] expectedSingleColumnResults = {
            1000.0, 
            2000.0, 
            5000.0  
        };
        assertArrayEquals(expectedSingleColumnResults, HolidayBonus.calculateHolidayBonus(singleColumnSalesData), 0.001);
        assertEquals(8000.0, HolidayBonus.calculateTotalHolidayBonus(singleColumnSalesData), 0.001);
    }
}


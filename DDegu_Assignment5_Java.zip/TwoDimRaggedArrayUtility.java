package assginment5;
import java.io.*;
import java.util.ArrayList;

public class TwoDimRaggedArrayUtility {

   public static double[][] readFile(File inputFile) throws NumberFormatException, IOException {
       ArrayList<double[]> dataList = new ArrayList<>();
       try (BufferedReader bufferedReader = new BufferedReader(new FileReader(inputFile))) {
           String currentLine;
           try {
               while ((currentLine = bufferedReader.readLine()) != null) {
                   String[] lineParts = currentLine.split(" ");
                   double[] rowArray = new double[lineParts.length];
                   for (int index = 0; index < lineParts.length; index++) {
                       rowArray[index] = Double.parseDouble(lineParts[index]);
                   }
                   dataList.add(rowArray);
               }
           } catch (NumberFormatException | IOException exception) {
               exception.printStackTrace();
           }
       }
       return dataList.toArray(new double[dataList.size()][]);
   }

   public static void writeToFile(double[][] arrayData, File outputFile) throws FileNotFoundException {
       try (PrintWriter fileWriter = new PrintWriter(outputFile)) {
           for (double[] rowArray : arrayData) {
               for (int index = 0; index < rowArray.length; index++) {
                   fileWriter.print(rowArray[index]);
                   if (index < rowArray.length - 1) fileWriter.print(" ");
               }
               fileWriter.println();
           }
       }
   }

   public static double getTotal(double[][] arrayData) {
       double totalSum = 0;
       for (double[] rowArray : arrayData) {
           for (double value : rowArray) {
               totalSum += value;
           }
       }
       return totalSum;
   }

   public static double getAverage(double[][] arrayData) {
       double totalSum = getTotal(arrayData);
       int elementCount = 0;
       for (double[] rowArray : arrayData) {
           elementCount += rowArray.length;
       }
       return totalSum / elementCount;
   }

   public static double getRowTotal(double[][] arrayData, int rowIndex) {
       double rowSum = 0;
       for (double value : arrayData[rowIndex]) {
           rowSum += value;
       }
       return rowSum;
   }

   public static double getColumnTotal(double[][] arrayData, int columnIndex) {
       double columnSum = 0;
       for (double[] rowArray : arrayData) {
           if (columnIndex < rowArray.length) {
               columnSum += rowArray[columnIndex];
           }
       }
       return columnSum;
   }

   public static double getHighestInRow(double[][] arrayData, int rowIndex) {
       double highestValue = arrayData[rowIndex][0];
       for (double value : arrayData[rowIndex]) {
           if (value > highestValue) highestValue = value;
       }
       return highestValue;
   }

   public static int getHighestInRowIndex(double[][] arrayData, int rowIndex) {
       int highestIndex = 0;
       double highestValue = arrayData[rowIndex][0];
       for (int index = 0; index < arrayData[rowIndex].length; index++) {
           if (arrayData[rowIndex][index] > highestValue) {
               highestValue = arrayData[rowIndex][index];
               highestIndex = index;
           }
       }
       return highestIndex;
   }

   public static double getLowestInRow(double[][] arrayData, int rowIndex) {
       double lowestValue = arrayData[rowIndex][0];
       for (double value : arrayData[rowIndex]) {
           if (value < lowestValue) lowestValue = value;
       }
       return lowestValue;
   }

   public static int getLowestInRowIndex(double[][] arrayData, int rowIndex) {
       int lowestIndex = 0;
       double lowestValue = arrayData[rowIndex][0];
       for (int index = 0; index < arrayData[rowIndex].length; index++) {
           if (arrayData[rowIndex][index] < lowestValue) {
               lowestValue = arrayData[rowIndex][index];
               lowestIndex = index;
           }
       }
       return lowestIndex;
   }

   public static double getHighestInColumn(double[][] arrayData, int columnIndex) {
       double highestValue = Double.NEGATIVE_INFINITY;
       for (double[] rowArray : arrayData) {
           if (columnIndex < rowArray.length && rowArray[columnIndex] > highestValue) {
               highestValue = rowArray[columnIndex];
           }
       }
       return highestValue;
   }

   public static int getHighestInColumnIndex(double[][] arrayData, int columnIndex) {
       int highestIndex = -1;
       double highestValue = Double.NEGATIVE_INFINITY;
       for (int rowIndex = 0; rowIndex < arrayData.length; rowIndex++) {
           if (columnIndex < arrayData[rowIndex].length && arrayData[rowIndex][columnIndex] > highestValue) {
               highestValue = arrayData[rowIndex][columnIndex];
               highestIndex = rowIndex;
           }
       }
       return highestIndex;
   }

   public static double getLowestInColumn(double[][] arrayData, int columnIndex) {
       double lowestValue = Double.POSITIVE_INFINITY;
       for (double[] rowArray : arrayData) {
           if (columnIndex < rowArray.length && rowArray[columnIndex] < lowestValue) {
               lowestValue = rowArray[columnIndex];
           }
       }
       return lowestValue;
   }

   public static int getLowestInColumnIndex(double[][] arrayData, int columnIndex) {
       int lowestIndex = -1;
       double lowestValue = Double.POSITIVE_INFINITY;
       for (int rowIndex = 0; rowIndex < arrayData.length; rowIndex++) {
           if (columnIndex < arrayData[rowIndex].length && arrayData[rowIndex][columnIndex] < lowestValue) {
               lowestValue = arrayData[rowIndex][columnIndex];
               lowestIndex = rowIndex;
           }
       }
       return lowestIndex;
   }

   public static double getHighestInArray(double[][] arrayData) {
       double highestValue = Double.NEGATIVE_INFINITY;
       for (double[] rowArray : arrayData) {
           for (double value : rowArray) {
               if (value > highestValue) highestValue = value;
           }
       }
       return highestValue;
   }

   public static double getLowestInArray(double[][] arrayData) {
       double lowestValue = Double.POSITIVE_INFINITY;
       for (double[] rowArray : arrayData) {
           for (double value : rowArray) {
               if (value < lowestValue) lowestValue = value;
           }
       }
       return lowestValue;
   }
}

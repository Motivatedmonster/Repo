package Patient;


	public class Procedure {
		private String nameOftheProcedure;
		private String date;
		private String nameOfPractitioner;
		private double chargerforProcedures;

		    // No-arg constructor
		    public Procedure() {
		        this.chargerforProcedures = 0.0;
		        this.date = "";
		        this.nameOfPractitioner = "";
		        this.nameOftheProcedure = "";
		    }
		    
		    public Procedure(String nameOftheProcedure, String date) {
		        this.nameOftheProcedure = nameOftheProcedure;
		        this.nameOfPractitioner = " ";
		        this.chargerforProcedures = 0.0;
		        this.date = date;
		    }
		    public Procedure(String nameOftheProcedure, String date, String nameOfPractitioner, double chargerforProcedures) {
		        this.nameOftheProcedure = nameOftheProcedure;
		        this.nameOfPractitioner = nameOfPractitioner;
		        this.chargerforProcedures = chargerforProcedures;
		        this.date = date;
		    }
		    // Mutators (setters)
		    public void setnameOftheProcedure(String nameOftheProcedure) {
		        this.nameOfPractitioner = nameOftheProcedure;
		    }
		    public void setnameOfPractitioner(String nameOfPractitioner) {
		        this.nameOfPractitioner = nameOfPractitioner;
		    }
		    public void setchargerforProcedures(Double chargerforProcedures) {
		        this.chargerforProcedures = chargerforProcedures;
		    }
		    public void setdate(String date) {
		        this.date = date;
		    }
		    // Accessors (getters)
		    public String getnameOftheProcedure() {
		        return nameOftheProcedure;
		    }
		    public String getrnameOfPractitioner() {
		        return nameOfPractitioner;
		    }
		    public double getchargerforProcedures() {
		        return chargerforProcedures;
		    }
		    public String getdate() {
		        return date;
		    }

		    public String toString() {
		        return "Procedure Information:\n" +
		             "Procedure Name: " + nameOftheProcedure + "\n" +
		    "Procedure Date: " + date + "\n" +
		      "Practitioner Name: " + nameOfPractitioner + "\n" +
		  "Procedure Charges: $" + chargerforProcedures;
		    }
		    
		}



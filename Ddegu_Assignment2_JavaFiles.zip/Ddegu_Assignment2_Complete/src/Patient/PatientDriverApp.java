package Patient;

/*
* Class: CMSC203 
* Instructor:
* Description: (Give a brief description for each Class)
* Due: MM/DD/YYYY
 * Platform/compiler:
* I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
Print your Name here: __________
*/

public class PatientDriverApp {
    public static void main(String[] args) {
        PatientDriverApp app = new PatientDriverApp();
    }
    public PatientDriverApp() {
        Patient patient = new Patient ("Dagi", "Jake", "Jax", "324 lake drive", "Rodetown", "NY", "10411", "301-123-4567", "Dagi Jake", "301-765-4321");          
        Procedure procedure1 = new Procedure();
            procedure1.setnameOftheProcedure("Physical Exam");
            procedure1.setdate("09/30/2024");
            procedure1.setnameOfPractitioner("Dr. Woody");
    procedure1.setchargerforProcedures(150.00);
    
            Procedure procedure2 = new Procedure();
            procedure2.setdate("09/28/2024");
            procedure2.setnameOftheProcedure("X-ray");
            procedure2.setnameOfPractitioner("Dr. John");
            procedure2.setchargerforProcedures(500.00);
    
    
            Procedure procedure3 = new Procedure();
            procedure3.setdate("09/27/2024");
            procedure3.setnameOftheProcedure("MRI");
            procedure3.setnameOfPractitioner("Dr. Bubbles");
            procedure3.setchargerforProcedures(750.00);
            double totalCharge = totalCharges(procedure1, procedure2, procedure3);
            
        displayPatient(patient);
         System.out.println();
        displayProcedure(procedure1);
        displayProcedure(procedure2);
        displayProcedure(procedure3);
        System.out.println("Total charges: $" + totalCharge);
    }
   public static void displayPatient(Patient patient) {
       System.out.println("Patient Information:" + patient);
    
   }
    public static void displayProcedure(Procedure procedure) {
        System.out.println("Procedure Info:\t" + procedure);
    }
    public static double totalCharges(Procedure procedure1, Procedure procedure2, Procedure procedure3) {
return procedure1.getchargerforProcedures() + procedure2.getchargerforProcedures() + procedure3.getchargerforProcedures();
        }
    }

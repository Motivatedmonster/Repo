package Patient;

public class Patient {
    // Fields
    private String firstName;
    private String middleName;
    private String lastName;
    private String streetAddress;
    private String city;
    private String state;
    private String zipCode;
    private String emergNmae;
  private String phoneNum;
    private String emergPhone;

    // No-arg 
    public Patient() {
        this.firstName = "";
        this.middleName = "";
        this.lastName = "";
        this.streetAddress = "";
        this.city = "";
        this.state = "";
        this.zipCode = "";
        this.phoneNum = "";
        this.emergNmae = "";
        this.emergPhone = "";
    }
  // Constructor for attributes
    public Patient(String firstName, String middleName, String lastName, String streetAddress, String city, 
                   String state, String zipCode, String phoneNum, String emergNmae, 
                   String emergPhone) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.streetAddress = streetAddress;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.phoneNum = phoneNum;
        this.emergNmae = emergNmae;
        this.emergPhone = emergPhone;
    }

    // Constructor 
    public Patient(String firstName, String middleName, String lastName) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.streetAddress = "";
        this.city = "";
        this.state = "";
        this.zipCode = "";
        this.phoneNum = "";
        this.emergNmae = "";
        this.emergPhone = "";
    }

  

  

    // Mutators (setters)
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public void setPhoneNumber(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public void setEmergencyContactName(String emergNmae) {
        this.emergNmae = emergNmae;
    }

    public void setEmergencyContactPhone(String emergPhone) {
        this.emergPhone = emergPhone;
    }

  // Accessors 
  public String getfirstName() {
      return firstName;
  }

  public String getmiddleName() {
      return middleName;
  }

  public String getlastName() {
      return lastName;
  }

  public String getstreetAddress() {
      return streetAddress;
  }

  public String getCity() {
      return city;
  }

  public String getState() {
      return state;
  }

  public String getzipCode() {
      return zipCode;
  }

  public String getphoneNum() {
      return phoneNum;
  }

  public String getemergNmae() {
      return emergNmae;
  }

  public String getemergPhone() {
      return emergPhone;
  }

    // Method for building fullname
    public String buildFullName() {
        return firstName + " " + middleName + " " + lastName;
    }

    // Method for fulladdress
    public String buildAddress() {
        return streetAddress + ", " + city + ", " + state + " " + zipCode;
    }

    // Method for for emergency contact 
    public String buildEmergencyContact() {
        return emergNmae + " (" + emergPhone + ")";
    }

    // toString method 
  
    public String toString() {
        return "Patient Information:\n" +
               "Full Name: " + buildFullName() + "\n" +
               "Address: " + buildAddress() + "\n" +
               "Phone: " + phoneNum + "\n" +
               "Emergency Contact: " + buildEmergencyContact();
    }
}

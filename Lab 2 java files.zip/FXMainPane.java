package application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class FXMainPane extends VBox {

    // Task #2: Declare buttons, a label, and a text field
    private Button btnHello;
    private Button btnHowdy;
    private Button btnChinese;
    private Button btnClear;
    private Button btnExit;
    private Label lblFeedback;
    private TextField txtInput;
    private HBox hBoxForButtons; // HBox for buttons
    private HBox hBoxForFeedback; // HBox for label and text field

    // Task #4: Declare an instance of DataManager
    private DataManager manager;

    FXMainPane() {
        // Task #2: Instantiate the buttons with specified arguments
        btnHello = new Button("Hello");
        btnHowdy = new Button("Howdy");
        btnChinese = new Button("Chinese");
        btnClear = new Button("Clear");
        btnExit = new Button("Exit");

        // Instantiate the label
        lblFeedback = new Label("Feedback:");
       
        // Instantiate the text field
        txtInput = new TextField();

        // Instantiate the HBoxes
        hBoxForButtons = new HBox(10); // spacing of 10 pixels between buttons
        hBoxForFeedback = new HBox(10); // spacing of 10 pixels between label and text field

        // Task #4: Instantiate the DataManager instance
        manager = new DataManager();
       
        // Set alignment and padding for HBoxes
        hBoxForButtons.setAlignment(Pos.CENTER);
        hBoxForButtons.setPadding(new Insets(10));
        hBoxForFeedback.setAlignment(Pos.CENTER);
        hBoxForFeedback.setPadding(new Insets(10));

        // Task #3: Add the buttons to the hBoxForButtons
        hBoxForButtons.getChildren().addAll(btnHello, btnHowdy, btnChinese, btnClear, btnExit);
       
        // Add the label and text field to hBoxForFeedback
        hBoxForFeedback.getChildren().addAll(lblFeedback, txtInput);
       
        // Add the HBoxes to this FXMainPane (a VBox)
        this.getChildren().addAll(hBoxForFeedback, hBoxForButtons);
       
        // Event handling for buttons
        btnHello.setOnAction(e -> {
            lblFeedback.setText(manager.getHello());
        });
        btnHowdy.setOnAction(e -> {
            lblFeedback.setText(manager.getHowdy());
        });
        btnChinese.setOnAction(e -> {
            lblFeedback.setText(manager.getChinese());
        });
        btnClear.setOnAction(e -> {
            lblFeedback.setText("Feedback:");
            txtInput.clear();
        });
        btnExit.setOnAction(e -> Platform.exit());
    }
}

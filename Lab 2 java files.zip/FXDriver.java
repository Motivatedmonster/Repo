package application;
import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FXDriver extends Application {
	
	/**
	* The main method for the GUI example program JavaFX version
	* @param args not used
	* @throws IOException
	*/
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		// Task #1: Instantiate FXMainPane
		FXMainPane mainPane = new FXMainPane();
		
		// Set the scene to hold mainPane
		primaryStage.setScene(new Scene(mainPane, 400, 300)); // You can adjust width and height as needed
		// Set stage title
		primaryStage.setTitle("Hello World GUI");
		// Display the stage
		primaryStage.show();
	}
}

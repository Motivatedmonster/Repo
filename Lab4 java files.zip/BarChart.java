package Lab4s;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.*;
import java.awt.Color;
public class BarChart implements ImageObserver {
    public static final int MAX_WIDTH = 400;
    public static final int START_X = 60;
    public static final int[] MAX_HEIGHTS = {220, 320, 420, 520};

    private Color[] rowColors = {Color.BLUE, new Color(150, 150, 0), Color.DARK_GRAY, Color.MAGENTA};
    private int[][] dataValues;

    private int barWidth;
    private int startX;
    private int currentActivity = 5;
    private int studentResult;
    private int expectedFrequency;
    private int expectedMinimum;
    private int keyValue;
    private boolean validateNewValues;

    public BarChart() {}

    public BarChart(int[][] inputData) {
        dataValues = new int[inputData.length][inputData[0].length];
        for (int i = 0; i < inputData.length; i++) {
            for (int j = 0; j < inputData[i].length; j++) {
                dataValues[i][j] = inputData[i][j];
            }
        }
        barWidth = (MAX_WIDTH - 20) / dataValues[0].length;
        studentResult = -1;
        expectedFrequency = -1;
        expectedMinimum = -1;
        keyValue = -1;
        validateNewValues = true;
    }

    public void updateDataValues(int[][] inputData) {
        for (int i = 0; i < inputData.length; i++) {
            for (int j = 0; j < inputData[i].length; j++) {
                dataValues[i][j] = inputData[i][j];
            }
        }
    }

    public void setStudentResult(int newResult) {
        studentResult = newResult;
    }

    public void setKeyValue(int newKey) {
        keyValue = newKey;
    }

    public int getExpectedFrequency() {
        return expectedFrequency;
    }

    public int getExpectedMinimum() {
        return expectedMinimum;
    }

    public boolean getValidateNewValues() {
        return validateNewValues;
    }

    public void setActivity(int activity) {
        currentActivity = activity;
    }

    public int getActivity() {
        return currentActivity;
    }

    public void updateBarChart(int key, int indexRow, int indexColumn, Graphics graphics) {
        draw(graphics);
        switch (currentActivity) {
            case 0: // Create new array values
                break;
            case 1: // Print out the array
                drawArray(indexRow, indexColumn, graphics);
                break;
            case 2: // Set all array values of a row to a certain value
                drawNewValue(indexRow, indexColumn, graphics);
                break;
            case 3: // Find the minimum in a column
                drawMinimum(indexRow, indexColumn, graphics);
                break;
            case 4: // Find the frequency of a value
                drawFrequency(indexRow, indexColumn, key, graphics);
                break;
        }
    }

    public void draw(Graphics graphics) {
        for (int i = 0; i < dataValues.length; i++) {
            startX = START_X;
            graphics.setColor(rowColors[i]);

            graphics.drawString("Row " + i, startX - 50, MAX_HEIGHTS[i]);

            for (int j = 0; j < dataValues[i].length; j++) {
                graphics.fillRect(startX, MAX_HEIGHTS[i] - dataValues[i][j], barWidth - 5, dataValues[i][j]);
                graphics.drawString("" + dataValues[i][j], startX, MAX_HEIGHTS[i] + 15);
                startX += barWidth;
            }
        }
    }

    public void drawArray(int indexRow, int indexColumn, Graphics graphics) {
        graphics.setColor(Color.RED);

        for (int i = 0; i < indexRow; i++) {
            startX = START_X;
            for (int j = 0; j < dataValues[i].length; j++) {
                graphics.fillRect(startX, MAX_HEIGHTS[i] - dataValues[i][j], barWidth - 5, dataValues[i][j]);
                graphics.drawString("" + dataValues[i][j], startX, MAX_HEIGHTS[i] + 15);
                startX += barWidth;
            }
        }

        startX = START_X;
        for (int j = 0; j <= indexColumn; j++) {
            graphics.fillRect(startX, MAX_HEIGHTS[indexRow] - dataValues[indexRow][j], barWidth - 5, dataValues[indexRow][j]);
            graphics.drawString("" + dataValues[indexRow][j], startX, MAX_HEIGHTS[indexRow] + 15);
            startX += barWidth;
        }
    }

    public void drawNewValue(int indexRow, int indexColumn, Graphics graphics) {
        graphics.setColor(Color.BLUE);
        validateNewValues(indexRow, indexColumn);

        String status = validateNewValues ? "correctly" : "incorrectly";
        graphics.drawString("Setting new array elements of row " + indexRow + " to " + keyValue, 25, 110);
        graphics.drawString("Up to index " + indexColumn + " , the new values are set " + status, 25, 130);

        graphics.setColor(Color.RED);
        startX = START_X;
        for (int j = 0; j <= indexColumn; j++) {
            graphics.fillRect(startX, MAX_HEIGHTS[indexRow] - dataValues[indexRow][j], barWidth - 5, dataValues[indexRow][j]);
            graphics.drawString("" + dataValues[indexRow][indexColumn], startX, MAX_HEIGHTS[indexRow] + 15);
            startX += barWidth;
        }
    }

    public void drawMinimum(int indexRow, int indexColumn, Graphics graphics) {
        int minVal = calculateSubMinimum(indexRow, indexColumn);
        if (indexColumn != -1) {
            graphics.setColor(Color.BLUE);
            graphics.drawString("Your current minimum in column " + indexColumn + ": " + studentResult, 25, 110);
            expectedMinimum = minVal;
            graphics.drawString("Correct current minimum in column " + indexColumn + ": " + expectedMinimum, 25, 130);

            graphics.setColor(Color.RED);
            startX = START_X + indexColumn * barWidth;
            graphics.drawRect(startX, MAX_HEIGHTS[indexRow] - dataValues[indexRow][indexColumn], barWidth - 5, dataValues[indexRow][indexColumn]);
            for (int i = 0; i <= indexRow; i++) {
                if (dataValues[i][indexColumn] == minVal) {
                    graphics.fillRect(startX, MAX_HEIGHTS[i] - dataValues[i][indexColumn], barWidth - 5, dataValues[i][indexColumn]);
                    break;
                }
            }
        }
    }

    public int calculateSubMinimum(int indexRow, int indexColumn) {
        int minValue = dataValues[0][indexColumn];
        for (int i = 1; i <= indexRow; i++) {
            if (minValue > dataValues[i][indexColumn])
                minValue = dataValues[i][indexColumn];
        }
        return minValue;
    }

    public void drawFrequency(int indexRow, int indexColumn, int value, Graphics graphics) {
        graphics.setColor(Color.BLUE);
        graphics.drawString("Your current frequency count: " + studentResult, 25, 110);
        expectedFrequency = calculateFrequency(indexRow, indexColumn, value);
        graphics.drawString("Correct current frequency count: " + expectedFrequency, 25, 130);

        graphics.setColor(Color.RED);
        for (int i = 0; i < indexRow; i++) {
            startX = START_X;
            for (int j = 0; j < dataValues[i].length; j++) {
                if (dataValues[i][j] == value)
                    graphics.fillRect(startX, MAX_HEIGHTS[i] - dataValues[i][j], barWidth - 5, dataValues[i][j]);
                startX += barWidth;
            }
        }

        startX = START_X + barWidth * indexColumn;
        graphics.drawRect(startX, MAX_HEIGHTS[indexRow] - value, barWidth - 5, value);
        startX = START_X;
        for (int j = 0; j <= indexColumn; j++) {
            if (dataValues[indexRow][j] == value)
                graphics.fillRect(startX, MAX_HEIGHTS[indexRow] - dataValues[indexRow][j], barWidth - 5, dataValues[indexRow][j]);
            startX += barWidth;
        }
    }

    public int calculateFrequency(int rowIndex, int colIndex, int searchValue) {
        int count = 0;
        for (int i = 0; i < rowIndex; i++) {
            for (int j = 0; j < dataValues[i].length; j++) {
                if (dataValues[i][j] == searchValue)
                    count++;
            }
        }

        for (int j = 0; j <= colIndex; j++) {
            if (dataValues[rowIndex][j] == searchValue)
                count++;
        }

        return count;
    }

    public void validateNewValues(int indexRow, int indexColumn) {
        validateNewValues = true;
        for (int i = 0; i <= indexColumn; i++) {
            if (keyValue != dataValues[indexRow][i])
                validateNewValues = false;
        }
    }

    public boolean imageUpdate(Image image, int infoflags, int x, int y, int width, int height) {
        return true;
    }
}



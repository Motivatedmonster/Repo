package Lab4s;
import java.awt.*;
import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.event.*;
import java.util.*;
public class TwoDimArrayPractice extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    // GUI components
    private JButton buttonFillValues;
    private JButton buttonPrintArray;
    private JButton buttonSetValues;
    private JButton buttonFindMinimum;
    private JButton buttonCountFrequency;

    private ButtonHandler buttonHandler;

    private static int[][] dataArray;
    private final int NUM_ROWS = 4;
    private final int NUM_COLUMNS = 20;
    private static int activeRow = -1;
    private static int activeColumn = -1;
    private int inputValue;
    private int selectedRow = -1;
    private int selectedColumn = -1;
    private BarChart barChart;
    private static int animationCounter = 0;

    public TwoDimArrayPractice() {
        super("Choose your activity");
        Container container = getContentPane();
        container.setLayout(new FlowLayout());

        buttonFillValues = new JButton("Fill Values");
        container.add(buttonFillValues);
        buttonPrintArray = new JButton("Print Array");
        container.add(buttonPrintArray);
        buttonSetValues = new JButton("Set Values");
        container.add(buttonSetValues);
        buttonFindMinimum = new JButton("Find Minimum");
        container.add(buttonFindMinimum);
        buttonCountFrequency = new JButton("Count Frequency");
        container.add(buttonCountFrequency);

        buttonHandler = new ButtonHandler();
        buttonFillValues.addActionListener(buttonHandler);
        buttonPrintArray.addActionListener(buttonHandler);
        buttonSetValues.addActionListener(buttonHandler);
        buttonFindMinimum.addActionListener(buttonHandler);
        buttonCountFrequency.addActionListener(buttonHandler);

        setSize(500, 550);

        dataArray = new int[NUM_ROWS][NUM_COLUMNS];

        // Fill with random numbers between 50 and 80
        Random randomGenerator = new Random();
        for (int i = 0; i < dataArray.length; i++) {
            for (int j = 0; j < dataArray[0].length; j++) {
                dataArray[i][j] = randomGenerator.nextInt(31) + 50;
            }
        }

        barChart = new BarChart(dataArray);

        // Print the array values
        System.out.println("Row\tValue");
        for (int i = 0; i < dataArray.length; i++) {
            System.out.print(i + "\t");
            for (int j = 0; j < dataArray[i].length; j++) {
                System.out.print(dataArray[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();

        setVisible(true);
        this.createImage(getSize().width, getSize().height);
    }

    // 1. Fills the array with random values between 50 and 80
    public void fillArrayValues() {
        Random randomGenerator = new Random();
        for (int row = 0; row < dataArray.length; row++) {
            System.out.print(row + "\t");
            for (int column = 0; column < dataArray[row].length; column++) {
                dataArray[row][column] = randomGenerator.nextInt(31) + 50;
                triggerAnimation(row, column);  // Needed to create visual feedback
            }
            System.out.println();
        }
    }

    // 2. Prints array to the console, elements are separated by a space
    public void displayArray() {
        System.out.println("Array contents:");
        for (int i = 0; i < dataArray.length; i++) {
            System.out.print(i + "\t");
            for (int j = 0; j < dataArray[i].length; j++) {
                System.out.print(dataArray[i][j] + " ");
                triggerAnimation(i, j); // Animation step for visual feedback
            }
            System.out.println();
        }
    }

    // 3. Sets all the elements in the specified row to the specified value
    public void updateRowValues(int value, int row) {
        for (int column = 0; column < dataArray[row].length; column++) {
            dataArray[row][column] = value;
            triggerAnimation(row, column); // Visual feedback
        }
    }

    // 4. Finds minimum value in the specified column
    public int findColumnMinimum(int column) {
        int min = dataArray[0][column];
        for (int row = 1; row < dataArray.length; row++) {
            if (dataArray[row][column] < min) {
                min = dataArray[row][column];
            }
            triggerAnimation(row, column, min); // Visual feedback
        }
        return min;
    }

    // 5. Finds the number of times a value is found in the array
    public int countOccurrences(int value) {
        int count = 0;
        for (int row = 0; row < dataArray.length; row++) {
            for (int column = 0; column < dataArray[row].length; column++) {
                if (dataArray[row][column] == value) {
                    count++;
                }
                triggerAnimation(row, column, count); // Visual feedback
            }
        }
        return count;
    }

    public void executeActivity(int activityIndex) {
        barChart.setActivity(activityIndex);
        boolean validInput = false;
        String userInput = "";
        switch (activityIndex) {
            case (0):
                fillArrayValues();
                JOptionPane.showMessageDialog(null, "Array filled with new values");
                break;

            case (1):
                displayArray();
                JOptionPane.showMessageDialog(null, "Array printed");
                break;

            case (2):
                while (!validInput || inputValue < 50 || inputValue > 80) {
                    try {
                        userInput = JOptionPane.showInputDialog(null, "Enter a value between 50 and 80");
                        if (userInput != null) {
                            inputValue = Integer.parseInt(userInput);
                            validInput = true;
                        } else {
                            validInput = false;
                            break;
                        }
                    } catch (Exception e) {
                    }
                }
                if (validInput) {
                    validInput = false;
                    while (!validInput || selectedRow < 0 || selectedRow > 3) {
                        try {
                            userInput = JOptionPane.showInputDialog(null, "Enter a row number between 0 and 3");
                            if (userInput != null) {
                                selectedRow = Integer.parseInt(userInput);
                                validInput = true;
                            } else {
                                validInput = false;
                                break;
                            }
                        } catch (Exception e) {
                        }
                    }
                }
                if (validInput) {
                    barChart.setKeyValue(inputValue);
                    updateRowValues(inputValue, selectedRow);
                    String message = "";
                    if (barChart.getValidateNewValues()) message = " correctly";
                    else message = " incorrectly";
                    JOptionPane.showMessageDialog(null, "Values in row " + selectedRow + " set to " + inputValue + message);
                }
                break;

            case (3):
                while (!validInput || selectedColumn < 0 || selectedColumn > 19) {
                    try {
                        userInput = JOptionPane.showInputDialog(null, "Enter a column number between 0 and 19");
                        if (userInput != null) {
                            selectedColumn = Integer.parseInt(userInput);
                            validInput = true;
                        } else {
                            validInput = false;
                            break;
                        }
                    } catch (Exception e) {
                    }
                }
                if (validInput) {
                    int minValue = findColumnMinimum(selectedColumn);
                    String feedbackMin = "";
                    if (minValue == barChart.getExpectedMinimum()) feedbackMin = "\nThis is correct";
                    else feedbackMin = "\nThis is incorrect";

                    String displayMessageMin = "In column " + selectedColumn + ", you found a minimum value of ";
                    displayMessageMin += minValue + feedbackMin;
                    JOptionPane.showMessageDialog(null, displayMessageMin);
                }
                break;

            case (4):
                while (!validInput || inputValue < 50 || inputValue > 80) {
                    try {
                        userInput = JOptionPane.showInputDialog(null, "Enter a value between 50 and 80");
                        if (userInput != null) {
                            inputValue = Integer.parseInt(userInput);
                            validInput = true;
                        } else {
                            validInput = false;
                            break;
                        }
                    } catch (Exception e) {
                    }
                }
                if (validInput) {
                    int frequency = countOccurrences(inputValue);
                    String feedbackFrequency = "";
                    if (frequency == barChart.getExpectedFrequency()) feedbackFrequency = "\nThis is correct";
                    else feedbackFrequency = "\nThis is incorrect";

                    String plural = "";
                    if (frequency != 1) plural = "s";

                    String displayMessageFrequency = "You found " + inputValue + " " + frequency + " time" + plural;
                    displayMessageFrequency += feedbackFrequency;

                    if (frequency != -1) JOptionPane.showMessageDialog(null, displayMessageFrequency);
                    else JOptionPane.showMessageDialog(null, "You did not find the value " + inputValue);
                }
                break;
        }
        enableButtons();
    }

    private void enableButtons() {
		// TODO Auto-generated method stub
		
	}

	public static int getActiveRow() {
        return activeRow;
    }

    public static int getActiveColumn() {
        return activeColumn;
    }

    public static int getAnimationCounter() {
        return animationCounter;
    }

    public static int[][] getDataArray() {
        return dataArray;
    }

    private void triggerAnimation(int row, int column) {
        if (barChart.getActivity() >= 0 && barChart.getActivity() <= 2) {
            activeRow = row;
            activeColumn = column;
            animationCounter++;
            repaint();
            try {
                Thread.sleep(100);
            } catch (Exception e) {
            }
        }
    }

    private void triggerAnimation(int row, int column, int val) {
        if (barChart.getActivity() >= 0 && barChart.getActivity() <= 2) {
            activeRow = row;
            activeColumn = column;
            animationCounter++;
            repaint();
            try {
                Thread.sleep(100);
            } catch (Exception e) {
            }
        }
    }

    private class ButtonHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == buttonFillValues)
                executeActivity(0);
            else if (e.getSource() == buttonPrintArray)
                executeActivity(1);
            else if (e.getSource() == buttonSetValues)
                executeActivity(2);
            else if (e.getSource() == buttonFindMinimum)
                executeActivity(3);
            else if (e.getSource() == buttonCountFrequency)
                executeActivity(4);
        }
    }

    public static void main(String[] args) {
        new TwoDimArrayPractice();
    }
}